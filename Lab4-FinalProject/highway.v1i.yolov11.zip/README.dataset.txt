# highway > 2023-09-07 11:46am
https://universe.roboflow.com/maksim-nezis/highway-aaxmv

Provided by a Roboflow user
License: CC BY 4.0

